<?php $__env->startSection("content"); ?>
bsisn
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temp.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furd3434/public_html/views/admin/landing.blade.php ENDPATH**/ ?>