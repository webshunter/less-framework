<?php $this->layout('temp/layout', ['title' => 'LOGIN PROGRAM ABSENSI']) ?>

<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-12 col-sm-8 col-lg-6">
            <div class="card mt-100">
                <div class="card-body">
                    <h3>POST !</h3>
                    <p>halaman ini hanya bisa diakses dengan post method</p>
                </div>
            </div>
        </div>
    </div>
</div>
