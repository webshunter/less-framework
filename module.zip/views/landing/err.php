<?php $this->layout('temp/layout', ['title' => 'LOGIN PROGRAM ABSENSI']) ?>

<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-12 col-sm-8 col-lg-6">
            <div class="card mt-100">
                <div class="card-body">
                    <h1>404 !</h1>
                    <p>Page Not Found</p>
                </div>
            </div>
        </div>
    </div>
</div>
