@extends('temp.admin')

@section("content")
bsisn
@endsection