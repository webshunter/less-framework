<style>

    .foto{
        text-align: center;
    }

    .foto img{
       width: 150px;
       height: 150px;
    }

    .foto h1{
        font-size: 18pt;
    }

    .foto p {
        display : inline-block;
        max-width : 250px;
    }

    .foto-area{
        display: inline-block;
        position: relative;
        margin-bottom: 20px;
    }

    .foto-area > i{
        position: absolute;
        bottom: 0;
        right: -10px;
        font-size: 25px;
        cursor: pointer;
    }

</style>