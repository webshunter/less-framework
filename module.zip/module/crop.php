<?php

class Croper{
    
}